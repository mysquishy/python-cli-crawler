from setuptools import setup

setup(
    name="crawler_cli",
    version="0.1.0",
    description="A feature-rich Python CLI for web crawling with semantic search and Qdrant persistence.",
    author="Your Name",
    author_email="your.email@example.com",
    py_modules=["main"],
    install_requires=[
        "requests",
        "aiohttp",
        "beautifulsoup4",
        "qdrant-client",
        "sentence-transformers",
        "torch",
        "transformers",
        "scikit-learn"
    ],
    entry_points={
        "console_scripts": [
            "crawler-cli=main:main"
        ]
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ]
)
